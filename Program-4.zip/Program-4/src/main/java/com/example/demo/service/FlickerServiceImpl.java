package com.example.demo.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FlickerServiceImpl implements IFlickerService{

    public static Map<String, List<String>> userFavorite = new HashMap<>();

    @Override
    public String login(String username) {
        if(userFavorite.get(username) == null){
            userFavorite.put(username, new ArrayList<>());
        }
        return "success";
    }

    @Override
    public String addFavorite(String username, String imageId) {
        userFavorite.get(username).add(imageId);
        return "success";
    }

    @Override
    public String removeFavorite(String username, String imageId) {
        if(userFavorite.get(username)!=null){
            int index = userFavorite.get(username).indexOf(imageId);
            if(index == -1){
                return "Lobster not found";
            }
            userFavorite.get(username).remove(index);
        }
        return "success";
    }

    @Override
    public List<String> getFavorite(String username) {
        if(userFavorite.get(username) == null){
            return new ArrayList<>();
        }
        return userFavorite.get(username);
    }
}
