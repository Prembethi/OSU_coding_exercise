package com.example.demo.controller;

import com.example.demo.service.IFlickerService;
import com.example.demo.wrapper.UserDetailWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.ws.rs.QueryParam;
import java.util.List;

@Controller
@RequestMapping("/flicker")
public class FlickerController {

    @Autowired
    private IFlickerService flickerService;

    @Value("${apiKey}")
    private String apiKey;

    @Value("${galleryId}")
    private String galleryId;

    @RequestMapping(method = RequestMethod.GET, value = "/login")
    @ResponseBody
    @CrossOrigin
    public String login(@QueryParam("username") String username) {
        return flickerService.login(username);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/addFavorite")
    @ResponseBody
    @CrossOrigin
    public String addFavorite(@QueryParam("username") String username,
                              @QueryParam("imageId") String imageId) {
        return flickerService.addFavorite(username, imageId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/removeFavorite")
    @ResponseBody
    @CrossOrigin
    public String removeFavorite(@QueryParam("username") String username,
                              @QueryParam("imageId") String imageId) {
        return flickerService.removeFavorite(username, imageId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getFavorite")
    @ResponseBody
    @CrossOrigin
    public UserDetailWrapper getFavorite(@QueryParam("username") String username) {
        UserDetailWrapper userDetailWrapper =  new UserDetailWrapper();
        userDetailWrapper.setFavorites(flickerService.getFavorite(username));
        userDetailWrapper.setApikey(apiKey);
        userDetailWrapper.setGalleryId(galleryId);
        return userDetailWrapper;
    }


}
