package com.example.demo.service;

import java.util.List;

public interface IFlickerService {
    String login(String username);

    String addFavorite(String username, String imageId);

    String removeFavorite(String username, String imageId);

    List<String> getFavorite(String username);
}
