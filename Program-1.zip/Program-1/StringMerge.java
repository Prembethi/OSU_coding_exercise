package com.tutorials.exercise;

public class StringMerge {
	
	public static void main(String[] args) {
		
		String str1 = "lobster";
		String str2 = "hello";
		
		String s1 = "";
		String s2 = "";
		if(str2.length()>str1.length()) {
			s2 = str1;
			s1 = str2;
		} else {
			s1 = str1;
			s2 = str2;
		}
		String finalStr = "";
		for(int i=0; i<s2.length();i++) {
			System.out.println(i+" : "+s1.charAt(i)+" : "+s2.charAt(i));
			finalStr+=s1.charAt(i)+""+s2.charAt(i);
		}
		finalStr+=s1.substring(s2.length(), s1.length());
		System.out.println(finalStr);
		
	}

}
