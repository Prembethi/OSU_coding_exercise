package com.tutorials.exercise;

public class StringPermutations {

	public static void main(String[] args) {
		String str = "STATE";
		printPermutation(str, "");
	}
	
	public static void printPermutation(String str, String a) {
		if(str.length() == 0) {
			System.out.println(a);
		}
		for(int i=0; i< str.length(); i++) {
			String ros = str.substring(0, i)+str.substring(i+1);
			printPermutation(ros, a+str.charAt(i));
		}
	}
}
