package com.example.demo.service;

import java.util.List;
import java.util.Map;

public interface ILobsterService {
    String create(String type, String lobster);

    String update(String type, String oldLobster, String newLobster);

    String delete(String type, String lobster);

    List<String> get(String type);

    Map<String, List<String>> getAll();
}

