package com.example.demo.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LobsterServiceImpl implements ILobsterService{

    public static Map<String, List<String>> lobsterData = new HashMap<>();

    @Override
    public String create(String type, String lobster) {
        if(lobsterData.get(type) == null){
            lobsterData.put(type, new ArrayList<>());
        }
        lobsterData.get(type).add(lobster);
        return "Lobster added successfully";
    }

    @Override
    public String update(String type, String oldLobster, String newLobster) {
        delete(type, oldLobster);
        create(type, newLobster);
        return "Lobster updated successfully";
    }

    @Override
    public String delete(String type, String lobster) {
        if(lobsterData.get(type)!=null){
            int index = lobsterData.get(type).indexOf(lobster);
            if(index == -1){
                return "Lobster not found";
            }
            lobsterData.get(type).remove(index);
        }
        return "Lobster deleted successfully";
    }

    @Override
    public List<String> get(String type) {
        if(lobsterData.get(type) == null){
            return new ArrayList<>();
        }
        return lobsterData.get(type);
    }

    @Override
    public Map<String, List<String>> getAll() {
        return lobsterData;
    }
}
