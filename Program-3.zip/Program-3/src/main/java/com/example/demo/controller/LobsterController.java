package com.example.demo.controller;

import com.example.demo.service.ILobsterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.ws.rs.QueryParam;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/lobster")
public class LobsterController {

    @Autowired
    private ILobsterService lobsterService;

    @RequestMapping(method = RequestMethod.GET, value = "/create")
    @ResponseBody
    public String create(@QueryParam("type") String type, @QueryParam("lobster") String lobster) {
        return lobsterService.create(type, lobster);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/update")
    @ResponseBody
    public String update(@QueryParam("type") String type, @QueryParam("oldLobster") String oldLobster,
                         @QueryParam("newLobster") String newLobster) {
        return lobsterService.update(type, oldLobster, newLobster);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/delete")
    @ResponseBody
    public String delete(@QueryParam("type") String type, @QueryParam("lobster") String lobster) {
        return lobsterService.delete(type, lobster);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/get")
    @ResponseBody
    public List<String> get(@QueryParam("type") String type) {
        return lobsterService.get(type);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getAll")
    @ResponseBody
    public Map<String, List<String>> getAll() {
        return lobsterService.getAll();
    }
}
